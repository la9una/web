## Selectores CSS - Ejercicio 3

Escribí dentro del archivo `selectores_03.css` los estilos CSS necesarios, (y modificá el archivo `selectores_03.html`, si es necesario) teniendo en cuenta las siguientes consignas:

| Elemento a estilizar | Condición                              | Estilo a aplicar                    |
| -------------------- | -------------------------------------- | ----------------------------------- |
| `<section>`          | Usar selector `id`                     | Borde y fondo a elección            |
| `<p>`                | Usar selector `class`. Aplicar a todos | Texto en itálica                    |
| `<h1>`               | Hijo de `<div>`                        | Color rojo                          |
| `<h2>`               | Hermano de `<h1>`                      | Color violeta                       |
| `<p>`                | Hermano directo de `<h1>`              | Color de fondo amarillo             |
| `<a>`                | Descendiente de `<div>`                | Color verde                         |
| `<a>`                | Aplicar a todos                        | Color anaranjado al pasar el cursor |



