#!/bin/bash

# Todas las fuentes en directorio actual e hijos
FUENTES=$(find . -type f -name '*.ttf')

# Convirtiendo fuentes .ttf a .eot
echo "Conviertiendo TTF a EOT"; 
sleep 1

for afile in $FUENTES
do
	output=${afile:0:(-3)}eot
	echo convert from $afile to $output
	ttf2eot $afile $output
done

# Convirtiendo fuentes .ttf a .woff
echo "Conviertiendo TTF a WOFF"; 
sleep 1

for font in $FUENTES
do 
	ttf2woff -t woff $font $font.woff 
done


