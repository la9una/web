## Selectores CSS - Ejercicio 4

Escribí dentro del archivo `selectores_04.css` los estilos CSS necesarios teniendo en cuenta las siguientes consignas:

| Elemento a estilizar | Condición                 | Estilo a aplicar                |
| -------------------- | ------------------------- | ------------------------------- |
| `<p>`                | Hijo de `<div>`           | Color verde                     |
| `<h2>`               | Hermano de `<h1>`         | Color violeta                   |
| `<p>`                | Hermano directo de `<h1>` | Color de fondo amarillo         |
| `<a>`                | Descendiente de `<div>`   | Color rojo, sin subrayado       |
| `<a>`                | Aplicar a todos           | Color  negro al pasar el cursor |



